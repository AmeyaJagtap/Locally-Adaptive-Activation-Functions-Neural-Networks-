from __future__ import print_function
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable

class LeNet(nn.Module):
    def __init__(self, nc, nh, hw, num_classes, act_func, adapt=0, n=1.0):
        input_shape = (nc,nh,hw)
        super(LeNet, self).__init__()
        self.maxpool = nn.MaxPool2d((2,2))      
        self.conv1 = nn.Conv2d(nc,64,5)    
        self.conv2 = nn.Conv2d(64,64,5)        
        self.flat_shape, shape1, shape2 = self.get_flat_shape(input_shape)            
        self.fc1 = nn.Linear(self.flat_shape, 1024)
        self.fc2 = nn.Linear(1024, num_classes)

        self.act_func = act_func
        
        # adding adaptive parameter
        self.adapt = adapt
        self.n = n
        if self.adapt == 1:
            self.adaptive = nn.Parameter(torch.tensor(1.0/self.n))            
        elif self.adapt == 2:
            self.adaptive1 = nn.Parameter(torch.tensor(1.0/self.n))
            self.adaptive2 = nn.Parameter(torch.tensor(1.0/self.n))
            self.adaptive3 = nn.Parameter(torch.tensor(1.0/self.n))             
        elif self.adapt == 3:
            self.adaptive1 = nn.Parameter(torch.ones(shape1)/self.n)
            self.adaptive2 = nn.Parameter(torch.ones(shape2)/self.n)  
            self.adaptive3 = nn.Parameter(torch.ones(1024)/self.n)               
        
    def get_flat_shape(self, input_shape):
        dummy0 = Variable(torch.zeros(1, *input_shape))
        dummy1 = self.maxpool(self.conv1(dummy0))
        dummy2 = self.maxpool(self.conv2(dummy1))
        return dummy2.data.view(1, -1).size(1), dummy1.data.size(), dummy2.data.size()
        
    def forward(self, x_in):        
        # conv 1
        x = self.conv1(x_in)
        x = self.maxpool(x)
        if self.adapt == 1:
            x = self.n * self.adaptive * x
        elif self.adapt == 2 or self.adapt == 3:
            x = self.n * self.adaptive1 * x         
        x = self.act_func(x)
        # conv 2
        x = self.conv2(x)
        x = self.maxpool(x)
        if self.adapt == 1:
            x = self.n * self.adaptive * x 
        elif self.adapt == 2 or self.adapt == 3:
            x = self.n * self.adaptive2 * x             
        x = self.act_func(x)
        # flatten
        x = x.view(-1,self.flat_shape)
        # fc 1
        x = self.fc1(x)
        if self.adapt == 1:
            x = self.n * self.adaptive * x
        elif self.adapt == 2 or self.adapt == 3:
            x = self.n * self.adaptive3 * x             
        x = self.act_func(x)
        x = F.dropout(x, p=0.5, training=self.training)
        # fc 2
        x_out1 = self.fc2(x)            
        
        return x_out1      

